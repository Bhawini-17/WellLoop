# WellLoop Health Monitoring Application

## Overview

WellLoop is a comprehensive health monitoring application designed specifically for managing chronic conditions like diabetes and hypertension. The application provides medication tracking, mood monitoring, AI-powered health coaching, and telehealth capabilities in a mobile-first interface.

## System Architecture

The application follows a full-stack architecture with:
- **Frontend**: React with TypeScript using Vite for build tooling
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom health-focused color scheme
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing

## Key Components

### Frontend Architecture
- **Mobile-first Design**: Optimized for smartphone usage with responsive layouts
- **Component Library**: Shadcn/ui providing accessible, customizable components
- **Custom Styling**: Health-focused gradient design with green-to-blue color scheme
- **Responsive Navigation**: Bottom navigation bar for mobile interaction patterns

### Backend Architecture
- **RESTful API**: Express.js server handling CRUD operations
- **Type Safety**: Shared TypeScript schemas between client and server
- **Storage Layer**: Abstracted storage interface supporting both in-memory and database implementations
- **Middleware**: Request logging, JSON parsing, and error handling

### Database Schema
The application uses Drizzle ORM with PostgreSQL, featuring:
- **Users**: Basic profile information (name, age, phone, region)
- **Medications**: Comprehensive medication tracking with dosage and timing
- **Medical Conditions**: User's health conditions management
- **Daily Data**: Mood tracking, notes, and medication compliance
- **Chat Messages**: AI conversation history
- **Prescriptions**: OCR-processed prescription data

## Data Flow

1. **User Interaction**: Mobile-optimized interface captures user inputs
2. **API Communication**: TanStack Query manages API calls with caching
3. **Server Processing**: Express routes handle business logic
4. **Database Operations**: Drizzle ORM manages data persistence
5. **Response Handling**: Real-time UI updates with optimistic mutations

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **class-variance-authority**: Styling utilities
- **date-fns**: Date manipulation
- **multer**: File upload handling

### Development Tools
- **Vite**: Frontend build tool with hot module replacement
- **TypeScript**: Type safety across the stack
- **Tailwind CSS**: Utility-first styling
- **ESBuild**: Server-side bundling for production

## Deployment Strategy

### Development Environment
- **Replit Integration**: Configured for Replit development environment
- **Hot Reloading**: Vite development server with Express backend
- **Database**: PostgreSQL module configured in Replit

### Production Build
- **Frontend**: Vite builds optimized static assets
- **Backend**: ESBuild bundles server code for Node.js execution
- **Autoscale Deployment**: Configured for Replit's autoscale deployment target

### Environment Configuration
- Database connection via `DATABASE_URL` environment variable
- Development/production mode switching
- Replit-specific tooling integration

## Changelog

### Recent Enhancements
- June 27, 2025: Enhanced calendar with visual indicators (colored dots) showing days with mood, notes, and medication data
- June 27, 2025: Integrated OpenAI Vision API for prescription OCR processing that automatically extracts and adds medications
- June 27, 2025: Added database initialization with default user and medication data
- June 27, 2025: Improved prescription upload feedback showing number of medications added
- June 27, 2025: Added calendar legend explaining the data indicator system

Changelog:
- June 27, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.