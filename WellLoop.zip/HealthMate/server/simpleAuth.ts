import session from "express-session";
import type { Express, RequestHandler } from "express";
import connectPg from "connect-pg-simple";

// Simple session-based auth without external providers
export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: true,
    ttl: sessionTtl,
    tableName: "user_sessions",
  });
  
  return session({
    secret: process.env.SESSION_SECRET || "wellloop-dev-secret",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true in production
      maxAge: sessionTtl,
    },
  });
}

export async function setupSimpleAuth(app: Express) {
  app.use(getSession());
  
  // Simple login route - for development/demo
  app.post("/api/auth/login", (req, res) => {
    const { username, password } = req.body;
    
    // For demo purposes, accept any login
    if (username && password) {
      (req.session as any).userId = 1; // Default to user ID 1
      (req.session as any).username = username;
      res.json({ success: true, user: { id: 1, name: username } });
    } else {
      res.status(400).json({ message: "Username and password required" });
    }
  });
  
  // Check auth status
  app.get("/api/auth/user", (req, res) => {
    const userId = (req.session as any)?.userId;
    if (userId) {
      res.json({ id: userId, name: (req.session as any).username || "User" });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });
  
  // Logout
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        res.status(500).json({ message: "Logout failed" });
      } else {
        res.json({ success: true });
      }
    });
  });
}

// Simple auth middleware
export const requireAuth: RequestHandler = (req, res, next) => {
  const userId = (req.session as any)?.userId;
  if (userId) {
    (req as any).userId = userId;
    next();
  } else {
    res.status(401).json({ message: "Authentication required" });
  }
};