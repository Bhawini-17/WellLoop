import { storage } from "./storage";

export async function initializeDatabase() {
  try {
    // Check if default user exists
    const existingUser = await storage.getUser(1);
    
    if (!existingUser) {
      console.log("Initializing database with default data...");
      
      // Create default user
      const defaultUser = await storage.createUser({
        name: "Rajesh Kumar",
        age: 45,
        phone: "+91-9876543210",
        region: "Pune"
      });

      // Create default medical conditions
      await storage.createMedicalCondition({
        userId: defaultUser.id,
        name: "Diabetes"
      });

      await storage.createMedicalCondition({
        userId: defaultUser.id,
        name: "Hypertension"
      });

      // Create default medications
      await storage.createMedication({
        userId: defaultUser.id,
        name: "Metformin",
        dosage: "500mg",
        time: "08:00",
        reason: "For Diabetes"
      });

      await storage.createMedication({
        userId: defaultUser.id,
        name: "Amlodipine",
        dosage: "5mg",
        time: "20:00",
        reason: "For Hypertension"
      });

      console.log("Database initialized successfully!");
    }
  } catch (error) {
    console.error("Failed to initialize database:", error);
  }
}