import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function getAIHealthResponse(message: string, userContext?: {
  name?: string;
  conditions?: string[];
  medications?: Array<{ name: string; dosage: string; reason: string }>;
}): Promise<string> {
  try {
    const systemPrompt = `You are an AI Health Coach specializing in diabetes and hypertension management. You provide helpful, accurate health advice while always recommending users consult their healthcare providers for medical decisions.

User Context:
${userContext?.name ? `Name: ${userContext.name}` : ''}
${userContext?.conditions?.length ? `Conditions: ${userContext.conditions.join(', ')}` : ''}
${userContext?.medications?.length ? `Current Medications: ${userContext.medications.map(m => `${m.name} ${m.dosage} (${m.reason})`).join(', ')}` : ''}

Guidelines:
- Provide personalized advice based on their conditions and medications
- Always emphasize consulting healthcare providers for medical decisions
- Focus on diabetes and hypertension management
- Include practical tips for diet, exercise, medication adherence
- Be supportive and encouraging
- Keep responses concise but informative`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I'm here to help with your health questions. Please try asking again.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    return "I'm experiencing some technical difficulties. Please try again later or consult your healthcare provider.";
  }
}

export async function extractMedicationsFromImage(base64Image: string): Promise<{
  extractedText: string;
  medications: Array<{ name: string; dosage: string; frequency: string; reason?: string }>;
}> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a medical prescription analyzer. Extract medication information from prescription images and return structured data.

Return JSON in this exact format:
{
  "extractedText": "full text you can read from the image",
  "medications": [
    {
      "name": "medication name",
      "dosage": "dosage amount with units",
      "frequency": "how often to take (e.g., 'twice daily', 'once daily', 'every 8 hours')",
      "reason": "condition it treats (if mentioned)"
    }
  ]
}

Focus on:
- Medication names (generic and brand names)
- Dosage amounts and units (mg, ml, etc.)
- Frequency instructions
- Any medical conditions mentioned
- Be conservative - only extract what you can clearly read`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Please extract all medication information from this prescription image and return structured JSON data."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ]
        }
      ],
      max_tokens: 1000,
      temperature: 0.1,
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"extractedText": "", "medications": []}');
    return {
      extractedText: result.extractedText || "",
      medications: result.medications || []
    };
  } catch (error) {
    console.error("OpenAI Vision API error:", error);
    return {
      extractedText: "Error processing image",
      medications: []
    };
  }
}