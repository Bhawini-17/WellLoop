import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { 
  insertUserSchema, insertMedicationSchema, insertMedicalConditionSchema, 
  insertDailyDataSchema, insertChatMessageSchema, insertPrescriptionSchema 
} from "@shared/schema";
import { z } from "zod";
import { getAIHealthResponse, extractMedicationsFromImage } from "./openai";

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(app: Express): Promise<Server> {
  const currentUserId = 1; // Default user for MVP

  // User routes
  app.get("/api/user", async (req, res) => {
    try {
      const user = await storage.getUser(currentUserId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  app.put("/api/user", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.updateUser(currentUserId, userData);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  // Medication routes
  app.get("/api/medications", async (req, res) => {
    try {
      const medications = await storage.getMedications(currentUserId);
      res.json(medications);
    } catch (error) {
      res.status(500).json({ message: "Failed to get medications" });
    }
  });

  app.post("/api/medications", async (req, res) => {
    try {
      const medicationData = insertMedicationSchema.parse({
        ...req.body,
        userId: currentUserId,
      });
      const medication = await storage.createMedication(medicationData);
      res.json(medication);
    } catch (error) {
      res.status(400).json({ message: "Invalid medication data" });
    }
  });

  app.delete("/api/medications/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteMedication(id);
      if (!success) {
        return res.status(404).json({ message: "Medication not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete medication" });
    }
  });

  // Medical condition routes
  app.get("/api/medical-conditions", async (req, res) => {
    try {
      const conditions = await storage.getMedicalConditions(currentUserId);
      res.json(conditions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get medical conditions" });
    }
  });

  app.post("/api/medical-conditions", async (req, res) => {
    try {
      const conditionData = insertMedicalConditionSchema.parse({
        ...req.body,
        userId: currentUserId,
      });
      const condition = await storage.createMedicalCondition(conditionData);
      res.json(condition);
    } catch (error) {
      res.status(400).json({ message: "Invalid condition data" });
    }
  });

  app.delete("/api/medical-conditions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteMedicalCondition(id);
      if (!success) {
        return res.status(404).json({ message: "Condition not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete condition" });
    }
  });

  // Daily data routes
  app.get("/api/daily-data", async (req, res) => {
    try {
      const { date } = req.query;
      if (date) {
        const dailyData = await storage.getDailyData(currentUserId, date as string);
        res.json(dailyData || null);
      } else {
        const allData = await storage.getAllDailyData(currentUserId);
        res.json(allData);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to get daily data" });
    }
  });

  app.post("/api/daily-data", async (req, res) => {
    try {
      const dailyData = insertDailyDataSchema.parse({
        ...req.body,
        userId: currentUserId,
      });
      const result = await storage.upsertDailyData(dailyData);
      res.json(result);
    } catch (error) {
      res.status(400).json({ message: "Invalid daily data" });
    }
  });

  // Chat routes
  app.get("/api/chat-messages", async (req, res) => {
    try {
      const messages = await storage.getChatMessages(currentUserId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to get chat messages" });
    }
  });

  app.post("/api/chat-messages", async (req, res) => {
    try {
      const { message } = req.body;
      
      // Get user context for personalized AI responses
      const user = await storage.getUser(currentUserId);
      const medications = await storage.getMedications(currentUserId);
      const conditions = await storage.getMedicalConditions(currentUserId);
      
      const userContext = {
        name: user?.name,
        conditions: conditions.map(c => c.name),
        medications: medications.map(m => ({
          name: m.name,
          dosage: m.dosage,
          reason: m.reason
        }))
      };
      
      const response = await getAIHealthResponse(message, userContext);
      
      const chatMessage = insertChatMessageSchema.parse({
        userId: currentUserId,
        message,
        response,
      });
      
      const result = await storage.createChatMessage(chatMessage);
      res.json(result);
    } catch (error) {
      console.error("Chat error:", error);
      res.status(400).json({ message: "Invalid chat message" });
    }
  });

  // Prescription upload route with OCR
  app.post("/api/prescriptions", upload.single("prescription"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Convert image to base64 for OpenAI Vision API
      const base64Image = req.file.buffer.toString('base64');
      
      // Extract medications using OpenAI Vision
      const ocrResult = await extractMedicationsFromImage(base64Image);
      
      // Save prescription record
      const prescription = insertPrescriptionSchema.parse({
        userId: currentUserId,
        filename: req.file.originalname,
        extractedText: ocrResult.extractedText,
      });
      
      const savedPrescription = await storage.createPrescription(prescription);
      
      // Auto-add extracted medications to user's medication list
      const addedMedications = [];
      for (const med of ocrResult.medications) {
        try {
          const medicationData = insertMedicationSchema.parse({
            userId: currentUserId,
            name: med.name,
            dosage: med.dosage,
            time: "08:00", // Default time, user can edit later
            reason: med.reason || "From prescription",
          });
          
          const addedMed = await storage.createMedication(medicationData);
          addedMedications.push(addedMed);
        } catch (medError) {
          console.warn("Failed to add medication:", med.name, medError);
        }
      }
      
      res.json({
        prescription: savedPrescription,
        extractedMedications: addedMedications,
        ocrResult
      });
    } catch (error) {
      console.error("Prescription upload error:", error);
      res.status(400).json({ message: "Failed to process prescription" });
    }
  });

  app.get("/api/prescriptions", async (req, res) => {
    try {
      const prescriptions = await storage.getPrescriptions(currentUserId);
      res.json(prescriptions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get prescriptions" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
