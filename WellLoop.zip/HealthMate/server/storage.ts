import { 
  users, medications, medicalConditions, dailyData, chatMessages, prescriptions,
  type User, type InsertUser, type UpsertUser, type Medication, type InsertMedication,
  type MedicalCondition, type InsertMedicalCondition, type DailyData, type InsertDailyData,
  type ChatMessage, type InsertChatMessage, type Prescription, type InsertPrescription
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Medication operations
  getMedications(userId: number): Promise<Medication[]>;
  createMedication(medication: InsertMedication): Promise<Medication>;
  updateMedication(id: number, medication: Partial<InsertMedication>): Promise<Medication | undefined>;
  deleteMedication(id: number): Promise<boolean>;
  
  // Medical condition operations
  getMedicalConditions(userId: number): Promise<MedicalCondition[]>;
  createMedicalCondition(condition: InsertMedicalCondition): Promise<MedicalCondition>;
  deleteMedicalCondition(id: number): Promise<boolean>;
  
  // Daily data operations
  getDailyData(userId: number, date: string): Promise<DailyData | undefined>;
  getAllDailyData(userId: number): Promise<DailyData[]>;
  upsertDailyData(data: InsertDailyData): Promise<DailyData>;
  
  // Chat operations
  getChatMessages(userId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Prescription operations
  createPrescription(prescription: InsertPrescription): Promise<Prescription>;
  getPrescriptions(userId: number): Promise<Prescription[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private medications: Map<number, Medication> = new Map();
  private medicalConditions: Map<number, MedicalCondition> = new Map();
  private dailyData: Map<string, DailyData> = new Map(); // key: userId-date
  private chatMessages: Map<number, ChatMessage> = new Map();
  private prescriptions: Map<number, Prescription> = new Map();
  
  private currentUserId = 1;
  private currentMedicationId = 1;
  private currentConditionId = 1;
  private currentDailyDataId = 1;
  private currentChatId = 1;
  private currentPrescriptionId = 1;

  constructor() {
    // Add default user and data
    const defaultUser: User = {
      id: 1,
      name: "Rajesh Kumar",
      age: 45,
      phone: "+91-9876543210",
      region: "Pune",
      createdAt: new Date(),
    };
    this.users.set(1, defaultUser);

    // Add default medications
    const defaultMedications: Medication[] = [
      { id: 1, userId: 1, name: "Metformin", dosage: "500mg", time: "08:00", reason: "For Diabetes", isActive: true },
      { id: 2, userId: 1, name: "Amlodipine", dosage: "5mg", time: "20:00", reason: "For Hypertension", isActive: true },
    ];
    defaultMedications.forEach(med => this.medications.set(med.id, med));

    // Add default medical conditions
    const defaultConditions: MedicalCondition[] = [
      { id: 1, userId: 1, name: "Diabetes", isActive: true },
      { id: 2, userId: 1, name: "Hypertension", isActive: true },
    ];
    defaultConditions.forEach(cond => this.medicalConditions.set(cond.id, cond));

    this.currentUserId = 2;
    this.currentMedicationId = 3;
    this.currentConditionId = 3;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = { 
      ...insertUser, 
      id: this.currentUserId++,
      createdAt: new Date()
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Medication operations
  async getMedications(userId: number): Promise<Medication[]> {
    return Array.from(this.medications.values()).filter(med => med.userId === userId && med.isActive);
  }

  async createMedication(insertMedication: InsertMedication): Promise<Medication> {
    const medication: Medication = {
      ...insertMedication,
      id: this.currentMedicationId++,
      isActive: insertMedication.isActive ?? true,
    };
    this.medications.set(medication.id, medication);
    return medication;
  }

  async updateMedication(id: number, medicationData: Partial<InsertMedication>): Promise<Medication | undefined> {
    const medication = this.medications.get(id);
    if (!medication) return undefined;
    
    const updatedMedication = { ...medication, ...medicationData };
    this.medications.set(id, updatedMedication);
    return updatedMedication;
  }

  async deleteMedication(id: number): Promise<boolean> {
    const medication = this.medications.get(id);
    if (!medication) return false;
    
    medication.isActive = false;
    this.medications.set(id, medication);
    return true;
  }

  // Medical condition operations
  async getMedicalConditions(userId: number): Promise<MedicalCondition[]> {
    return Array.from(this.medicalConditions.values()).filter(cond => cond.userId === userId && cond.isActive);
  }

  async createMedicalCondition(insertCondition: InsertMedicalCondition): Promise<MedicalCondition> {
    const condition: MedicalCondition = {
      ...insertCondition,
      id: this.currentConditionId++,
      isActive: insertCondition.isActive ?? true,
    };
    this.medicalConditions.set(condition.id, condition);
    return condition;
  }

  async deleteMedicalCondition(id: number): Promise<boolean> {
    const condition = this.medicalConditions.get(id);
    if (!condition) return false;
    
    condition.isActive = false;
    this.medicalConditions.set(id, condition);
    return true;
  }

  // Daily data operations
  async getDailyData(userId: number, date: string): Promise<DailyData | undefined> {
    const key = `${userId}-${date}`;
    return this.dailyData.get(key);
  }

  async getAllDailyData(userId: number): Promise<DailyData[]> {
    return Array.from(this.dailyData.values()).filter(data => data.userId === userId);
  }

  async upsertDailyData(insertData: InsertDailyData): Promise<DailyData> {
    const key = `${insertData.userId}-${insertData.date}`;
    const existing = this.dailyData.get(key);
    
    if (existing) {
      const updated = { ...existing, ...insertData };
      this.dailyData.set(key, updated);
      return updated;
    } else {
      const newData: DailyData = {
        ...insertData,
        id: this.currentDailyDataId++,
      };
      this.dailyData.set(key, newData);
      return newData;
    }
  }

  // Chat operations
  async getChatMessages(userId: number): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values()).filter(msg => msg.userId === userId);
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const message: ChatMessage = {
      ...insertMessage,
      id: this.currentChatId++,
      timestamp: new Date(),
    };
    this.chatMessages.set(message.id, message);
    return message;
  }

  // Prescription operations
  async createPrescription(insertPrescription: InsertPrescription): Promise<Prescription> {
    const prescription: Prescription = {
      ...insertPrescription,
      id: this.currentPrescriptionId++,
      uploadedAt: new Date(),
    };
    this.prescriptions.set(prescription.id, prescription);
    return prescription;
  }

  async getPrescriptions(userId: number): Promise<Prescription[]> {
    return Array.from(this.prescriptions.values()).filter(presc => presc.userId === userId);
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getMedications(userId: number): Promise<Medication[]> {
    return await db
      .select()
      .from(medications)
      .where(eq(medications.userId, userId));
  }

  async createMedication(insertMedication: InsertMedication): Promise<Medication> {
    const [medication] = await db
      .insert(medications)
      .values(insertMedication)
      .returning();
    return medication;
  }

  async updateMedication(id: number, medicationData: Partial<InsertMedication>): Promise<Medication | undefined> {
    const [medication] = await db
      .update(medications)
      .set(medicationData)
      .where(eq(medications.id, id))
      .returning();
    return medication || undefined;
  }

  async deleteMedication(id: number): Promise<boolean> {
    const result = await db
      .update(medications)
      .set({ isActive: false })
      .where(eq(medications.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getMedicalConditions(userId: number): Promise<MedicalCondition[]> {
    return await db
      .select()
      .from(medicalConditions)
      .where(eq(medicalConditions.userId, userId));
  }

  async createMedicalCondition(insertCondition: InsertMedicalCondition): Promise<MedicalCondition> {
    const [condition] = await db
      .insert(medicalConditions)
      .values(insertCondition)
      .returning();
    return condition;
  }

  async deleteMedicalCondition(id: number): Promise<boolean> {
    const result = await db
      .update(medicalConditions)
      .set({ isActive: false })
      .where(eq(medicalConditions.id, id));
    return (result.rowCount || 0) > 0;
  }

  async getDailyData(userId: number, date: string): Promise<DailyData | undefined> {
    const [dailyDataRecord] = await db
      .select()
      .from(dailyData)
      .where(and(eq(dailyData.userId, userId), eq(dailyData.date, date)));
    return dailyDataRecord || undefined;
  }

  async getAllDailyData(userId: number): Promise<DailyData[]> {
    return await db
      .select()
      .from(dailyData)
      .where(eq(dailyData.userId, userId));
  }

  async upsertDailyData(insertData: InsertDailyData): Promise<DailyData> {
    const existing = await this.getDailyData(insertData.userId, insertData.date);
    
    if (existing) {
      const [updated] = await db
        .update(dailyData)
        .set(insertData)
        .where(eq(dailyData.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(dailyData)
        .values(insertData)
        .returning();
      return created;
    }
  }

  async getChatMessages(userId: number): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, userId));
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db
      .insert(chatMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async createPrescription(insertPrescription: InsertPrescription): Promise<Prescription> {
    const [prescription] = await db
      .insert(prescriptions)
      .values(insertPrescription)
      .returning();
    return prescription;
  }

  async getPrescriptions(userId: number): Promise<Prescription[]> {
    return await db
      .select()
      .from(prescriptions)
      .where(eq(prescriptions.userId, userId));
  }
}

// Use database storage by default, fallback to memory if DB not available
let storage: IStorage;
try {
  storage = new DatabaseStorage();
} catch (error) {
  console.warn("Database not available, using memory storage:", error);
  storage = new MemStorage();
}

export { storage };
