import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AddConditionModal() {
  const [open, setOpen] = useState(false);
  const [conditionName, setConditionName] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const conditionMutation = useMutation({
    mutationFn: async (name: string) => {
      return apiRequest("POST", "/api/medical-conditions", { name });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medical-conditions"] });
      setOpen(false);
      setConditionName("");
      toast({
        title: "Success",
        description: "Medical condition added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add medical condition",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (conditionName.trim()) {
      conditionMutation.mutate(conditionName.trim());
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="w-full border-2 border-dashed border-gray-300 rounded-lg p-4 text-gray-600 hover:border-gray-400 hover:text-gray-700 transition-colors">
          <Plus className="w-4 h-4 inline mr-2" />
          Add Medical Condition
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add Medical Condition</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="conditionName">Condition Name</Label>
            <Input
              id="conditionName"
              value={conditionName}
              onChange={(e) => setConditionName(e.target.value)}
              placeholder="Enter condition name"
              required
            />
          </div>
          <div className="flex space-x-3">
            <Button type="submit" disabled={conditionMutation.isPending} className="flex-1">
              Save
            </Button>
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="flex-1">
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
