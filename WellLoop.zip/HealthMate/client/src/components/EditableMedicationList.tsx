import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Edit, Trash2 } from "lucide-react";
import type { Medication } from "@shared/schema";

interface EditableMedicationListProps {
  medications: Medication[];
}

export default function EditableMedicationList({ medications }: EditableMedicationListProps) {
  const [editingMed, setEditingMed] = useState<Medication | null>(null);
  const [newMed, setNewMed] = useState({ name: "", dosage: "", time: "", reason: "" });
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addMutation = useMutation({
    mutationFn: async (data: any) => apiRequest(`/api/medications`, "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medications"] });
      setNewMed({ name: "", dosage: "", time: "", reason: "" });
      setShowAddDialog(false);
      toast({ title: "Success", description: "Medication added successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add medication", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: any) => apiRequest(`/api/medications/${editingMed?.id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medications"] });
      setEditingMed(null);
      setShowEditDialog(false);
      toast({ title: "Success", description: "Medication updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update medication", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => apiRequest(`/api/medications/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medications"] });
      toast({ title: "Success", description: "Medication deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete medication", variant: "destructive" });
    },
  });

  const handleAddMedication = () => {
    if (newMed.name && newMed.dosage && newMed.time) {
      addMutation.mutate(newMed);
    }
  };

  const handleUpdateMedication = () => {
    if (editingMed) {
      updateMutation.mutate({
        name: editingMed.name,
        dosage: editingMed.dosage,
        time: editingMed.time,
        reason: editingMed.reason,
      });
    }
  };

  const startEdit = (medication: Medication) => {
    setEditingMed(medication);
    setShowEditDialog(true);
  };

  return (
    <Card className="card-rounded shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold">Current Medications</CardTitle>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Medication
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Medication</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Medication Name</Label>
                <Input
                  id="name"
                  value={newMed.name}
                  onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
                  placeholder="e.g., Metformin"
                />
              </div>
              <div>
                <Label htmlFor="dosage">Dosage</Label>
                <Input
                  id="dosage"
                  value={newMed.dosage}
                  onChange={(e) => setNewMed({ ...newMed, dosage: e.target.value })}
                  placeholder="e.g., 500mg"
                />
              </div>
              <div>
                <Label htmlFor="time">Time</Label>
                <Input
                  id="time"
                  type="time"
                  value={newMed.time}
                  onChange={(e) => setNewMed({ ...newMed, time: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="reason">Reason</Label>
                <Input
                  id="reason"
                  value={newMed.reason}
                  onChange={(e) => setNewMed({ ...newMed, reason: e.target.value })}
                  placeholder="e.g., For Diabetes"
                />
              </div>
              <Button 
                onClick={handleAddMedication} 
                disabled={!newMed.name || !newMed.dosage || !newMed.time || addMutation.isPending}
                className="w-full"
              >
                {addMutation.isPending ? "Adding..." : "Add Medication"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {medications.map((medication) => (
            <div key={medication.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <div className="font-medium">{medication.name}</div>
                <div className="text-sm text-gray-600">
                  {medication.dosage} at {medication.time}
                </div>
                {medication.reason && (
                  <div className="text-xs text-gray-500">{medication.reason}</div>
                )}
              </div>
              <div className="flex space-x-2">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => startEdit(medication)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => deleteMutation.mutate(medication.id)}
                  disabled={deleteMutation.isPending}
                >
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Edit Dialog */}
        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Medication</DialogTitle>
            </DialogHeader>
            {editingMed && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-name">Medication Name</Label>
                  <Input
                    id="edit-name"
                    value={editingMed.name}
                    onChange={(e) => setEditingMed({ ...editingMed, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-dosage">Dosage</Label>
                  <Input
                    id="edit-dosage"
                    value={editingMed.dosage}
                    onChange={(e) => setEditingMed({ ...editingMed, dosage: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-time">Time</Label>
                  <Input
                    id="edit-time"
                    type="time"
                    value={editingMed.time}
                    onChange={(e) => setEditingMed({ ...editingMed, time: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-reason">Reason</Label>
                  <Input
                    id="edit-reason"
                    value={editingMed.reason}
                    onChange={(e) => setEditingMed({ ...editingMed, reason: e.target.value })}
                  />
                </div>
                <Button 
                  onClick={handleUpdateMedication} 
                  disabled={updateMutation.isPending}
                  className="w-full"
                >
                  {updateMutation.isPending ? "Updating..." : "Update Medication"}
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}