import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2 } from "lucide-react";
import type { MedicalCondition } from "@shared/schema";

interface EditableMedicalConditionsProps {
  conditions: MedicalCondition[];
}

export default function EditableMedicalConditions({ conditions }: EditableMedicalConditionsProps) {
  const [newCondition, setNewCondition] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addMutation = useMutation({
    mutationFn: async (name: string) => apiRequest(`/api/medical-conditions`, "POST", { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medical-conditions"] });
      setNewCondition("");
      setShowAddDialog(false);
      toast({ title: "Success", description: "Medical condition added successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add medical condition", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => apiRequest(`/api/medical-conditions/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/medical-conditions"] });
      toast({ title: "Success", description: "Medical condition deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete medical condition", variant: "destructive" });
    },
  });

  const handleAddCondition = () => {
    if (newCondition.trim()) {
      addMutation.mutate(newCondition.trim());
    }
  };

  return (
    <Card className="card-rounded shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-semibold">Medical History</CardTitle>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Condition
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Medical Condition</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="condition-name">Condition Name</Label>
                <Input
                  id="condition-name"
                  value={newCondition}
                  onChange={(e) => setNewCondition(e.target.value)}
                  placeholder="e.g., Diabetes, Hypertension"
                />
              </div>
              <Button 
                onClick={handleAddCondition} 
                disabled={!newCondition.trim() || addMutation.isPending}
                className="w-full"
              >
                {addMutation.isPending ? "Adding..." : "Add Condition"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {conditions.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No medical conditions recorded</p>
          ) : (
            conditions.map((condition) => (
              <div key={condition.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="font-medium">{condition.name}</div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => deleteMutation.mutate(condition.id)}
                  disabled={deleteMutation.isPending}
                >
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}