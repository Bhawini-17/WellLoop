import { useLocation } from "wouter";
import { Home, Phone, Calendar, Bot, User } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { path: "/", label: "Home", icon: Home },
  { path: "/call-system", label: "Call System", icon: Phone },
  { path: "/calendar", label: "Calendar", icon: Calendar },
  { path: "/ai-coach", label: "AI Coach", icon: Bot },
  { path: "/profile", label: "Profile", icon: User },
];

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 z-50">
      <div className="grid grid-cols-5 h-16">
        {navItems.map(({ path, label, icon: Icon }) => (
          <button
            key={path}
            onClick={() => setLocation(path)}
            className={cn(
              "flex flex-col items-center justify-center space-y-1 transition-colors",
              location === path ? "text-blue-500" : "text-gray-400 hover:text-gray-600"
            )}
          >
            <Icon className="w-5 h-5" />
            <span className="text-xs font-medium">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
