import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import { cn } from "@/lib/utils";

const moods = [
  { key: "happy", emoji: "😊" },
  { key: "good", emoji: "😃" },
  { key: "neutral", emoji: "😐" },
  { key: "sad", emoji: "😕" },
  { key: "sick", emoji: "🤒" },
];

interface MoodSelectorProps {
  selectedMood?: string;
}

export default function MoodSelector({ selectedMood }: MoodSelectorProps) {
  const [currentMood, setCurrentMood] = useState(selectedMood || "");
  const queryClient = useQueryClient();

  const moodMutation = useMutation({
    mutationFn: async (mood: string) => {
      const today = formatDate(new Date());
      return apiRequest("POST", "/api/daily-data", {
        date: today,
        mood: mood,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-data"] });
    },
  });

  const handleMoodSelect = (mood: string) => {
    setCurrentMood(mood);
    moodMutation.mutate(mood);
  };

  useEffect(() => {
    setCurrentMood(selectedMood || "");
  }, [selectedMood]);

  return (
    <div className="flex justify-between mt-6 space-x-3">
      {moods.map(({ key, emoji }) => (
        <button
          key={key}
          onClick={() => handleMoodSelect(key)}
          className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center text-xl transition-colors",
            "bg-white/20 hover:bg-white/30",
            currentMood === key && "mood-selected"
          )}
          disabled={moodMutation.isPending}
        >
          {emoji}
        </button>
      ))}
    </div>
  );
}
