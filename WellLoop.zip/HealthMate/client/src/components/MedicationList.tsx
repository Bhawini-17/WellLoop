import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Check } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { formatDate, formatTime } from "@/lib/utils";
import { cn } from "@/lib/utils";
import type { Medication } from "@shared/schema";

interface MedicationListProps {
  medications: Medication[];
  medicationsTaken: Record<string, boolean>;
}

export default function MedicationList({ medications, medicationsTaken }: MedicationListProps) {
  const queryClient = useQueryClient();

  const medicationMutation = useMutation({
    mutationFn: async ({ medicationName, taken }: { medicationName: string; taken: boolean }) => {
      const today = formatDate(new Date());
      const newMedicationsTaken = { ...medicationsTaken, [medicationName]: taken };
      
      return apiRequest("POST", "/api/daily-data", {
        date: today,
        medicationsTaken: newMedicationsTaken,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-data"] });
    },
  });

  const handleMedicationToggle = (medicationName: string) => {
    const currentlyTaken = medicationsTaken[medicationName] || false;
    medicationMutation.mutate({ medicationName, taken: !currentlyTaken });
  };

  return (
    <div className="space-y-4">
      {medications.map((medication) => {
        const isTaken = medicationsTaken[medication.name] || false;
        
        return (
          <div key={medication.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex-1">
              <h3 className="font-medium text-gray-900">{medication.name}</h3>
              <p className="text-sm text-gray-600">
                {medication.dosage} at {formatTime(medication.time)}
              </p>
              <p className="text-sm text-blue-600">{medication.reason}</p>
            </div>
            <button
              onClick={() => handleMedicationToggle(medication.name)}
              disabled={medicationMutation.isPending}
              className={cn(
                "w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors",
                isTaken
                  ? "bg-green-500 border-green-500 text-white"
                  : "border-gray-300 hover:border-gray-400"
              )}
            >
              {isTaken && <Check className="w-3 h-3" />}
            </button>
          </div>
        );
      })}
    </div>
  );
}
