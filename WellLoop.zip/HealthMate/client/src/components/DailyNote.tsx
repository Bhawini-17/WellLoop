import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Edit3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";

interface DailyNoteProps {
  note?: string;
}

export default function DailyNote({ note }: DailyNoteProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [noteText, setNoteText] = useState(note || "");
  const queryClient = useQueryClient();

  const noteMutation = useMutation({
    mutationFn: async (newNote: string) => {
      const today = formatDate(new Date());
      return apiRequest("POST", "/api/daily-data", {
        date: today,
        note: newNote,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-data"] });
      setIsEditing(false);
    },
  });

  const handleSave = () => {
    noteMutation.mutate(noteText);
  };

  const handleCancel = () => {
    setNoteText(note || "");
    setIsEditing(false);
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Daily Note</h2>
        <button
          onClick={() => setIsEditing(true)}
          className="text-blue-500 hover:text-blue-600 p-1"
        >
          <Edit3 className="w-4 h-4" />
        </button>
      </div>

      {isEditing ? (
        <div className="space-y-3">
          <Textarea
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="Add a note about your day..."
            rows={3}
            className="resize-none"
          />
          <div className="flex space-x-2">
            <Button
              onClick={handleSave}
              disabled={noteMutation.isPending}
              size="sm"
            >
              Save
            </Button>
            <Button
              onClick={handleCancel}
              variant="outline"
              size="sm"
            >
              Cancel
            </Button>
          </div>
        </div>
      ) : (
        <div className="text-gray-500">
          {note || "Tap the edit icon to add a note about your day..."}
        </div>
      )}
    </div>
  );
}
