import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import Calendar from "@/pages/Calendar";
import CallSystem from "@/pages/CallSystem";
import AICoach from "@/pages/AICoach";
import Profile from "@/pages/Profile";
import BottomNavigation from "@/components/BottomNavigation";

function Router() {
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen relative">
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/calendar" component={Calendar} />
        <Route path="/call-system" component={CallSystem} />
        <Route path="/ai-coach" component={AICoach} />
        <Route path="/profile" component={Profile} />
      </Switch>
      <BottomNavigation />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
