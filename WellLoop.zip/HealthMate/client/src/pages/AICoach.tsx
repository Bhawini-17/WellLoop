import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Send, Bot, User } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { getCurrentTimeFormatted } from "@/lib/utils";
import type { ChatMessage } from "@shared/schema";

interface DisplayMessage {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: string;
}

export default function AICoach() {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<DisplayMessage[]>([
    {
      id: "welcome",
      text: "Hello Rajesh Kumar! I'm your AI Health Coach. I can help you with questions about your diabetes and hypertension management, medications, diet, exercise, and general health concerns. What would you like to know today?",
      isUser: false,
      timestamp: getCurrentTimeFormatted()
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: chatHistory = [] } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat-messages"],
  });

  const chatMutation = useMutation({
    mutationFn: async (userMessage: string) => {
      return apiRequest("POST", "/api/chat-messages", { message: userMessage });
    },
    onSuccess: (data) => {
      const chatMessage = data as any;
      setMessages(prev => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          text: chatMessage.response,
          isUser: false,
          timestamp: getCurrentTimeFormatted()
        }
      ]);
    },
  });

  const quickQuestions = [
    "How should I take my medications?",
    "What foods are good for diabetes?",
    "Exercise tips for my conditions",
    "Managing stress and blood pressure"
  ];

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const userMessage: DisplayMessage = {
      id: `user-${Date.now()}`,
      text: message,
      isUser: true,
      timestamp: getCurrentTimeFormatted()
    };

    setMessages(prev => [...prev, userMessage]);
    chatMutation.mutate(message);
    setMessage("");
  };

  const handleQuickQuestion = (question: string) => {
    setMessage(question);
    handleSendMessage();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="screen-container">
      {/* Gradient Header */}
      <div className="gradient-primary p-6 rounded-b-3xl text-white">
        <h1 className="text-2xl font-semibold mb-2">AI Health Coach</h1>
        <p className="text-lg opacity-90">Ask me anything about your health</p>
      </div>

      <div className="flex flex-col h-full">
        {/* Chat Messages */}
        <div className="flex-1 p-6 space-y-4 overflow-y-auto max-h-96">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex items-start space-x-3 ${msg.isUser ? 'justify-end' : ''}`}>
              {!msg.isUser && (
                <div className="w-8 h-8 gradient-primary rounded-full flex items-center justify-center text-white text-sm font-medium">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div className={`rounded-lg p-3 max-w-xs ${
                msg.isUser 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-gray-100 text-gray-900'
              }`}>
                {!msg.isUser && (
                  <div className="text-xs text-gray-500 mb-1">{msg.timestamp}</div>
                )}
                <div className="text-sm">{msg.text}</div>
              </div>
              {msg.isUser && (
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-gray-600 text-sm font-medium">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Questions & Input */}
        <Card className="m-4 mt-0 card-rounded shadow-sm">
          <CardContent className="p-4">
            <div className="text-sm text-gray-600 mb-3">Quick questions:</div>
            <div className="flex flex-wrap gap-2 mb-4">
              {quickQuestions.map((question) => (
                <Button
                  key={question}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickQuestion(question)}
                  className="text-xs bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                >
                  {question}
                </Button>
              ))}
            </div>

            {/* Chat Input */}
            <div className="flex space-x-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your health question..."
                className="flex-1"
              />
              <Button
                onClick={handleSendMessage}
                disabled={chatMutation.isPending || !message.trim()}
                className="gradient-primary"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
