import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDate, formatDisplayDate, getMoodEmoji } from "@/lib/utils";
import { cn } from "@/lib/utils";
import type { DailyData } from "@shared/schema";

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());

  const { data: allDailyData = [] } = useQuery<DailyData[]>({
    queryKey: ["/api/daily-data"],
  });

  // Create a map for quick lookup
  const dailyDataMap = allDailyData.reduce((acc, data) => {
    acc[data.date] = data;
    return acc;
  }, {} as Record<string, DailyData>);

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const generateCalendarDays = () => {
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());

    const days = [];
    for (let i = 0; i < 42; i++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + i);
      days.push(date);
    }
    return days;
  };

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDate(new Date(date));
  };

  const calendarDays = generateCalendarDays();
  const selectedDateKey = formatDate(selectedDate);
  const selectedDateData = dailyDataMap[selectedDateKey];

  return (
    <div className="screen-container">
      <div className="p-6">
        {/* Calendar Header */}
        <div className="flex justify-between items-center mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={handlePrevMonth}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          </Button>
          <h2 className="text-xl font-semibold">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleNextMonth}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ChevronRight className="w-5 h-5 text-gray-600" />
          </Button>
        </div>

        {/* Calendar Grid */}
        <Card className="card-rounded shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-7 gap-1 mb-4">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {calendarDays.map((date) => {
                const dateKey = formatDate(date);
                const isCurrentMonth = date.getMonth() === currentDate.getMonth();
                const isSelected = dateKey === selectedDateKey;
                const dayData = dailyDataMap[dateKey];
                const hasData = !!dayData;
                const hasMood = dayData?.mood;
                const hasNote = dayData?.note;
                const hasMedicationsTaken = dayData?.medicationsTaken && Object.keys(dayData.medicationsTaken).length > 0;

                return (
                  <div key={dateKey} className="relative">
                    <button
                      onClick={() => handleDateSelect(date)}
                      className={cn(
                        "h-10 w-10 rounded-lg text-sm transition-colors relative",
                        isCurrentMonth ? "text-gray-900" : "text-gray-400",
                        isSelected
                          ? "gradient-primary text-white"
                          : "hover:bg-gray-100",
                        hasData && !isSelected && "bg-blue-50 border border-blue-200"
                      )}
                    >
                      {date.getDate()}
                    </button>
                    {/* Visual indicators for data */}
                    {hasData && (
                      <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 flex space-x-0.5">
                        {hasMood && (
                          <div className="w-1.5 h-1.5 bg-green-400 rounded-full"></div>
                        )}
                        {hasNote && (
                          <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                        )}
                        {hasMedicationsTaken && (
                          <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Legend */}
        <Card className="card-rounded shadow-sm mb-4">
          <CardContent className="p-4">
            <h3 className="text-sm font-medium mb-3 text-gray-700">Data Indicators</h3>
            <div className="flex justify-between text-xs">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Mood</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span>Note</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                <span>Medications</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Selected Date Info */}
        <Card className="card-rounded shadow-sm">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">
              {formatDisplayDate(selectedDate)}
            </h3>
            
            {selectedDateData ? (
              <div className="space-y-4">
                {selectedDateData.mood && (
                  <div className="flex items-center space-x-2">
                    <span className="font-medium">Mood:</span>
                    <span className="text-lg">{getMoodEmoji(selectedDateData.mood)}</span>
                    <span className="capitalize">{selectedDateData.mood}</span>
                  </div>
                )}
                
                {selectedDateData.note && (
                  <div>
                    <span className="font-medium">Note:</span>
                    <p className="mt-1 text-gray-700">{selectedDateData.note}</p>
                  </div>
                )}
                
                {selectedDateData.medicationsTaken && Object.keys(selectedDateData.medicationsTaken).length > 0 && (
                  <div>
                    <span className="font-medium">Medications taken:</span>
                    <ul className="list-disc list-inside mt-1 space-y-1">
                      {Object.entries(selectedDateData.medicationsTaken)
                        .filter(([_, taken]) => taken)
                        .map(([name]) => (
                          <li key={name} className="text-gray-700">{name}</li>
                        ))}
                    </ul>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-gray-500">
                No data recorded for this date
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
