import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Camera, Edit, User as UserIcon } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import EditableMedicationList from "@/components/EditableMedicationList";
import EditableMedicalConditions from "@/components/EditableMedicalConditions";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User, Medication, MedicalCondition } from "@shared/schema";

export default function Profile() {
  const [prescriptionFile, setPrescriptionFile] = useState<File | null>(null);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<User>>({});
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const { data: medications = [] } = useQuery<Medication[]>({
    queryKey: ["/api/medications"],
  });

  const { data: conditions = [] } = useQuery<MedicalCondition[]>({
    queryKey: ["/api/medical-conditions"],
  });

  const updateUserMutation = useMutation({
    mutationFn: async (data: Partial<User>) => apiRequest(`/api/user`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      setShowEditProfile(false);
      toast({ title: "Success", description: "Profile updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update profile", variant: "destructive" });
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("prescription", file);
      return apiRequest("/api/upload-prescription", "POST", formData);
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/medications"] });
      setPrescriptionFile(null);
      toast({
        title: "Success",
        description: `Prescription uploaded successfully! Added ${data.medicationsAdded} medications.`,
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to upload prescription", variant: "destructive" });
    },
  });

  const startEditProfile = () => {
    if (user) {
      setEditingUser({
        name: user.name,
        age: user.age,
        phone: user.phone,
        region: user.region,
      });
      setShowEditProfile(true);
    }
  };

  const handleUpdateProfile = () => {
    if (editingUser.name && editingUser.age && editingUser.phone && editingUser.region) {
      updateUserMutation.mutate(editingUser);
    }
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setPrescriptionFile(file);
    }
  };

  const handleUpload = () => {
    if (prescriptionFile) {
      uploadMutation.mutate(prescriptionFile);
    }
  };

  if (!user) {
    return (
      <div className="container mx-auto p-4 space-y-6">
        <div className="text-center">Loading...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4 space-y-6">
      {/* Profile Header */}
      <Card className="card-rounded shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center space-x-4">
            <Avatar className="w-16 h-16">
              <AvatarFallback className="bg-gradient-to-r from-green-500 to-blue-500 text-white text-xl font-bold">
                <UserIcon className="w-8 h-8" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
              <p className="text-gray-600">{user.age} years old • {user.region}</p>
              <p className="text-gray-600">{user.phone}</p>
            </div>
          </div>
          <Dialog open={showEditProfile} onOpenChange={setShowEditProfile}>
            <DialogTrigger asChild>
              <Button variant="outline" onClick={startEditProfile}>
                <Edit className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Profile</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={editingUser.name || ""}
                    onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={editingUser.age || ""}
                    onChange={(e) => setEditingUser({ ...editingUser, age: parseInt(e.target.value) })}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={editingUser.phone || ""}
                    onChange={(e) => setEditingUser({ ...editingUser, phone: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="region">Region</Label>
                  <Input
                    id="region"
                    value={editingUser.region || ""}
                    onChange={(e) => setEditingUser({ ...editingUser, region: e.target.value })}
                  />
                </div>
                <Button 
                  onClick={handleUpdateProfile} 
                  disabled={updateUserMutation.isPending}
                  className="w-full"
                >
                  {updateUserMutation.isPending ? "Updating..." : "Update Profile"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
      </Card>

      {/* Prescription Upload */}
      <Card className="card-rounded shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Camera className="w-5 h-5 mr-2" />
            Upload Prescription
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Input 
              type="file" 
              accept="image/*" 
              onChange={handleFileChange}
              disabled={uploadMutation.isPending}
            />
            {prescriptionFile && (
              <div className="text-sm text-gray-600">
                Selected: {prescriptionFile.name}
              </div>
            )}
            <Button 
              onClick={handleUpload} 
              disabled={!prescriptionFile || uploadMutation.isPending}
              className="w-full"
            >
              {uploadMutation.isPending ? "Processing..." : "Upload and Extract Medications"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Medications */}
      <EditableMedicationList medications={medications} />

      {/* Medical Conditions */}
      <EditableMedicalConditions conditions={conditions} />
    </div>
  );
}