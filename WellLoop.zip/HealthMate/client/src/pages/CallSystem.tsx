import { useState } from "react";
import { Phone, Video, Building2, MessageCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function CallSystem() {
  const [showServices, setShowServices] = useState(false);

  const services = [
    {
      id: "virtual",
      name: "Virtual Checkup",
      description: "Online consultation with doctors",
      icon: Video,
      color: "bg-blue-100 text-blue-500"
    },
    {
      id: "in-person",
      name: "In-Person Checkup",
      description: "Visit hospital for physical examination",
      icon: Building2,
      color: "bg-green-100 text-green-500"
    },
    {
      id: "advisory",
      name: "Advisory",
      description: "AI-powered health advice",
      icon: MessageCircle,
      color: "bg-purple-100 text-purple-500"
    }
  ];

  const handleStartCall = () => {
    setShowServices(true);
  };

  const handleServiceSelect = (serviceId: string) => {
    // In a real app, this would initiate the selected service
    alert(`Initiating ${services.find(s => s.id === serviceId)?.name} service...`);
  };

  return (
    <div className="screen-container">
      {/* Gradient Header */}
      <div className="gradient-primary p-6 rounded-b-3xl text-white">
        <h1 className="text-2xl font-semibold mb-2">Healthcare Call Center</h1>
        <p className="text-lg opacity-90">Voice-enabled healthcare assistance</p>
      </div>

      {!showServices ? (
        <div className="p-6 flex flex-col items-center justify-center min-h-96">
          <div className="text-center mb-8">
            <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mb-6 mx-auto">
              <Phone className="w-8 h-8 text-blue-500" />
            </div>
            <h2 className="text-2xl font-semibold mb-4">Start Healthcare Call</h2>
            <p className="text-gray-600 mb-8">Click to begin voice-assisted healthcare service</p>
          </div>

          <Button
            onClick={handleStartCall}
            className="gradient-primary py-4 px-8 rounded-2xl text-lg font-medium hover:opacity-90 transition-opacity mb-6"
          >
            Start Call
          </Button>

          <div className="flex items-center space-x-3 text-gray-500">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
              <Phone className="w-5 h-5" />
            </div>
            <span>Voice Assistant</span>
          </div>
        </div>
      ) : (
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-6">Select Healthcare Service</h2>
          
          <div className="space-y-4">
            {services.map((service) => {
              const IconComponent = service.icon;
              
              return (
                <Card key={service.id} className="card-rounded shadow-sm">
                  <CardContent className="p-0">
                    <button
                      onClick={() => handleServiceSelect(service.id)}
                      className="w-full p-4 flex items-center space-x-4 hover:bg-gray-50 transition-colors rounded-2xl"
                    >
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${service.color}`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div className="text-left">
                        <div className="font-medium">{service.name}</div>
                        <div className="text-sm text-gray-600">{service.description}</div>
                      </div>
                    </button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
