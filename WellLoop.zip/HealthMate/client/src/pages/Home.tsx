import { useQuery } from "@tanstack/react-query";
import { Phone, Bot } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import MoodSelector from "@/components/MoodSelector";
import MedicationList from "@/components/MedicationList";
import DailyNote from "@/components/DailyNote";
import { formatDate, getGreeting } from "@/lib/utils";
import type { Medication, DailyData, User } from "@shared/schema";

export default function Home() {
  const [, setLocation] = useLocation();
  const today = formatDate(new Date());

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const { data: medications = [] } = useQuery<Medication[]>({
    queryKey: ["/api/medications"],
  });

  const { data: todayData } = useQuery<DailyData | null>({
    queryKey: ["/api/daily-data", { date: today }],
    queryFn: async () => {
      const response = await fetch(`/api/daily-data?date=${today}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch daily data");
      return response.json();
    },
  });

  const greeting = getGreeting();
  const userName = user?.name || "User";

  return (
    <div className="screen-container">
      {/* Gradient Header */}
      <div className="gradient-primary p-6 rounded-b-3xl text-white">
        <h1 className="text-2xl font-semibold mb-2">
          {greeting}, {userName}
        </h1>
        <p className="text-lg opacity-90">How are you feeling today?</p>
        
        <MoodSelector selectedMood={todayData?.mood} />
      </div>

      <div className="p-6 space-y-6">
        {/* Today's Medications */}
        <Card className="card-rounded shadow-sm">
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-4">Today's Medications</h2>
            <MedicationList 
              medications={medications} 
              medicationsTaken={todayData?.medicationsTaken || {}}
            />
          </CardContent>
        </Card>

        {/* Daily Note */}
        <DailyNote note={todayData?.note} />

        {/* Quick Actions */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-4">
            <Button
              onClick={() => setLocation("/call-system")}
              className="gradient-primary h-auto p-4 rounded-2xl flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity"
            >
              <Phone className="w-5 h-5" />
              <span className="font-medium">Healthcare Call</span>
            </Button>
            <Button
              onClick={() => setLocation("/ai-coach")}
              className="gradient-purple h-auto p-4 rounded-2xl flex items-center justify-center space-x-2 hover:opacity-90 transition-opacity"
            >
              <Bot className="w-5 h-5" />
              <span className="font-medium">AI Coach</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
